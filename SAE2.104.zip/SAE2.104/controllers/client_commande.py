#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint
from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g
from datetime import datetime
from connexion_db import get_db
from datetime import date

client_commande = Blueprint('client_commande', __name__,
                        template_folder='templates')


@client_commande.route('/client/commande/add', methods=['POST'])
def client_commande_add():
    mycursor = get_db().cursor()
    prix_total = request.form.get('prixTotal')
    client_id = session['user_id']
    mycursor.execute(
        "SELECT * FROM panier INNER JOIN chaussure ON panier.id_chaussure = chaussure.id_chaussure WHERE panier.id_user = %s",
        (client_id))
    items_panier = mycursor.fetchall()

    if items_panier is None:
        flash('Votre panier est vide...')
        return redirect(url_for('client_article_show'))

    nbr_articles = 0
    for item in items_panier:
        mycursor.execute("SELECT quantite FROM panier WHERE id_panier = %s;", (item['id_panier']))
        tmp = mycursor.fetchone()
        nbr_articles += tmp['quantite']

    mycursor.execute(
        "INSERT INTO commande(date_achat, prix_total, nbr_articles, id_user, id_etat ) VALUES(%s, %s, %s, %s, %s);",
        (date.today(), prix_total, nbr_articles, client_id, 1))
    mycursor.execute("SELECT last_insert_id() AS last_insert_id;")
    id_commande = mycursor.fetchone()

    for item in items_panier:
        mycursor.execute(
            "INSERT INTO ligne_commande(id_commande, id_chaussure, prix_unit, quantite) VALUES(%s, %s, %s, %s);",
            (id_commande['last_insert_id'], item['id_chaussure'], item['prix_unit'], item['quantite']))
        mycursor.execute("DELETE FROM panier WHERE id_user = %s AND id_chaussure = %s;", (client_id, item['id_chaussure']))

    get_db().commit()
    flash(u'Commande ajoutée')
    return redirect('/client/article/show')
    #return redirect(url_for('client_index'))



@client_commande.route('/client/commande/show', methods=['get','post'])
def client_commande_show():
    mycursor = get_db().cursor()
    commandes = None
    articles_commande = None

    commande_id = request.form.get('idCommande')

    if commande_id == None:
        mycursor.execute(
            "SELECT * FROM commande INNER JOIN etat ON commande.id_etat = etat.id_etat WHERE id_user = %s;",
            (session['user_id']))
        commandes = mycursor.fetchall()
        return render_template('client/commandes/show.html', commandes=commandes)

    mycursor.execute("SELECT * FROM commande INNER JOIN etat ON commande.id_etat = etat.id_etat WHERE id_user = %s;",
                     (session['user_id']))
    commandes = mycursor.fetchall()
    mycursor.execute(
        "SELECT * FROM ligne_commande INNER JOIN chaussure ON ligne_commande.id_chaussure = chaussure.id_chaussure WHERE id_commande = %s;",
        (id_commande))
    articles_commande = mycursor.fetchall()

    return render_template('client/commandes/show.html', commandes=commandes, articles_commande=articles_commande)


