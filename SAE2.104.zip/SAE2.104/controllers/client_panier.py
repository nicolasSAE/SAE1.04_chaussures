#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint
from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g

from connexion_db import get_db

client_panier = Blueprint('client_panier', __name__,
                        template_folder='templates')


@client_panier.route('/client/panier/add', methods=['POST'])
def client_panier_add():
    mycursor = get_db().cursor()
    client_id = session['user_id']
    id_article = request.form.get('idArticle')
    quantite = request.form.get('quantite')

    sql = "SELECT * FROM panier WHERE id_chaussure = %s AND id_user=%s"
    mycursor.execute(sql, (id_article, client_id))
    article_panier = mycursor.fetchone()

    mycursor.execute("SELECT * FROM chaussure WHERE id_chaussure = %s", (id_article))
    article = mycursor.fetchone()

    if not (article_panier is None) and article_panier['quantite'] >= 1:
        tuple_update = (quantite, client_id, id_article)
        sql = "UPDATE panier SET quantite = quantite+%s WHERE id_user = %s AND id_chaussure=%s"
        mycursor.execute(sql, tuple_update)
    else:
        tuple_insert = (client_id, id_article, quantite)
        sql = "INSERT INTO panier(id_user,id_chaussure,quantite) VALUES (%s,%s,%s)"
        mycursor.execute(sql, tuple_insert)

    get_db().commit()


    return redirect('/client/article/show')
    #return redirect(url_for('client_index'))

@client_panier.route('/client/panier/delete', methods=['POST'])
def client_panier_delete():
    mycursor = get_db().cursor()
    client_id = session['user_id']
    id_article = request.form.get('idArticle')
    quantite = request.form.get('quantite')

    if quantite >= 2:
        mycursor.execute("UPDATE chaussure SET stock = stock + 1 WHERE id_chaussure = %s;", (id_article))

        get_db().commit()
    else:
        mycursor.execute("UPDATE chaussure SET stock = stock + 1 WHERE id_chaussure = %s;", (id_article))
        mycursor.execute("DELETE FROM panier WHERE id_panier = %s AND user_id = %s;", (id_panier, session['user_id']))
        get_db().commit()
    return redirect('/client/article/show')
#return redirect(url_for('client_index'))


@client_panier.route('/client/panier/vider', methods=['POST'])
def client_panier_vider():
    mycursor = get_db().cursor()

    mycursor.execute("SELECT id_panier FROM panier;")
    ids = mycursor.fetchall()

    mycursor.execute("SELECT COUNT(*) AS nbrLignes FROM panier;")
    nbrLignes = mycursor.fetchone()
    nbrLignes = nbrLignes['nbrLignes']

    liste_ids = []

    for i in range(nbrLignes):
        id = ids[i]
        id = id['id_panier']
        liste_ids.append(id)

    for i in liste_ids:
        mycursor.execute("SELECT quantite FROM panier WHERE id_panier = %s AND id_user = %s", (i, session['user_id']))
        quantite = mycursor.fetchone()
        quantite = quantite['quantite']

        mycursor.execute("SELECT id_chaussure FROM panier WHERE id_panier = %s AND id_user = %s", (i, session['user_id']))
        id_chaussure = mycursor.fetchone()
        id_chaussure =  id_chaussure['id_chaussure']

        mycursor.execute("UPDATE chaussure SET stock = stock + %s WHERE id_chaussure = %s;", (quantite, id_chaussure))
        mycursor.execute("DELETE FROM panier WHERE id_panier = %s AND id_user = %s;", (i, session['user_id']))
    get_db().commit()


    return redirect('/client/article/show')
    #return redirect(url_for('client_index'))


@client_panier.route('/client/panier/delete/line', methods=['POST'])
def client_panier_delete_line():

    mycursor = get_db().cursor()
    client_id = session['user_id']
    id_article = request.form.get('idArticle')
    id_panier = request.form.get('id_panier')
    quantite = request.form.get('quantite')



    mycursor.execute("UPDATE chaussure SET stock = stock + %s WHERE id_chaussure = %s;", (quantite, id_article))
    mycursor.execute("DELETE FROM panier WHERE id_panier = %s AND id_user = %s;", (id_panier, session['user_id']))
    get_db().commit()
    return redirect('/client/article/show')
    #return redirect(url_for('client_index'))


@client_panier.route('/client/panier/filtre', methods=['POST'])
def client_panier_filtre():
    # SQL
    filter_word = request.form.get('filter_word', None)
    filter_prix_min = request.form.get('filter_prix_min', None)
    filter_prix_max = request.form.get('filter_prix_max', None)
    filter_types = request.form.getlist('filter_types', None)

    return redirect('/client/article/show')
    #return redirect(url_for('client_index'))


@client_panier.route('/client/panier/filtre/suppr', methods=['POST'])
def client_panier_filtre_suppr():
    session.pop('filter_word', None)
    session.pop('filter_prix_min', None)
    session.pop('filter_prix_max', None)
    session.pop('filter_types', None)
    print("suppr filtre")
    return redirect('/client/article/show')
    #return redirect(url_for('client_index'))