#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint
from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g

from connexion_db import get_db

admin_article = Blueprint('admin_article', __name__,
                        template_folder='templates')

@admin_article.route('/admin/article/show')
def show_article():
    mycursor = get_db().cursor()
    mycursor.execute("SELECT * FROM chaussure INNER JOIN type_chaussure ON chaussure.id_type_chaussure = type_chaussure.id_type_chaussure INNER JOIN marque ON chaussure.marque= marque.marque_id ORDER BY type_chaussure.id_type_chaussure ASC;")
    chaussure = mycursor.fetchall()
    return render_template('admin/article/show_article.html', chaussure=chaussure)

@admin_article.route('/admin/article/add', methods=['GET'])
def add_article():
    mycursor = get_db().cursor()
    mycursor.execute("SELECT * FROM type_chaussure ORDER BY libelle_type;")
    type_chaussure = mycursor.fetchall()
    mycursor.execute("SELECT * FROM marque ORDER BY marque_libelle;")
    marques = mycursor.fetchall()
    return render_template('admin/article/add_article.html', type_chaussure=type_chaussure, marques=marques)

@admin_article.route('/admin/article/valid-add', methods=['POST'])
def valid_add_article():
    return redirect(url_for('admin_article.show_article'))